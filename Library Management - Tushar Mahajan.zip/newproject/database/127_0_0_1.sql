-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2018 at 10:02 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarydb`
--
CREATE DATABASE IF NOT EXISTS `librarydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `librarydb`;

-- --------------------------------------------------------

--
-- Table structure for table `bookdb`
--

CREATE TABLE `bookdb` (
  `book_id` int(100) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `publication` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookdb`
--

INSERT INTO `bookdb` (`book_id`, `book_name`, `author`, `category`, `publication`) VALUES
(105, 'hotshot', 'karan', 'Others', 'csb pub'),
(106, 'delbisase', 'arthur treser', 'Self Help', 'penguin'),
(108, 'arihant chem', 'abcd', 'Self Help', 'arihant pub'),
(109, 'arihant phy', 'adb', 'Self Help', 'arihant pub'),
(110, 'arihant maths', 'zxe', 'Self Help', 'arihant pub'),
(111, 'pardeep chem', 'sh pardeep', 'Self Help', 'pardeep pub'),
(112, 'pardeep maths', 'dk singh', 'Self Help', 'pardeep pub'),
(113, 'maths nd', 'nand lal daya raam', 'Self Help', 'nd pub'),
(114, 'macroeconomics', 'sebs', 'Self Help', 'red spot pub'),
(115, 'micro economics', 'gestis', 'Self Help', 'lester pub'),
(116, 'fault in our stars', 'tuser', 'Novels', 'fds pub'),
(117, 'application of derivative', 'mathur', 'Self Help', 'als pub'),
(118, 'irodov', 'ie irodov', 'Self Help', 'iei pub'),
(119, 'scary movies ', 'quester', 'Novels', 'abd pub'),
(120, 'pablo escobar ', 'pablo', 'Novels', 'pw pub');

-- --------------------------------------------------------

--
-- Table structure for table `finetable`
--

CREATE TABLE `finetable` (
  `m_id` int(100) NOT NULL,
  `m_name` varchar(100) NOT NULL,
  `fineamt` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `finetable`
--

INSERT INTO `finetable` (`m_id`, `m_name`, `fineamt`) VALUES
(104, 'abhi', 40),
(107, 'alisha', 120);

-- --------------------------------------------------------

--
-- Table structure for table `issuedb`
--

CREATE TABLE `issuedb` (
  `b_id` int(100) NOT NULL,
  `b_name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `publication` varchar(300) NOT NULL,
  `m_id` int(100) NOT NULL,
  `m_name` varchar(100) NOT NULL,
  `issuedate` date NOT NULL,
  `returndate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issuedb`
--

INSERT INTO `issuedb` (`b_id`, `b_name`, `author`, `category`, `publication`, `m_id`, `m_name`, `issuedate`, `returndate`) VALUES
(107, 'story of my life', 'junior', 'Others', 'ncert', 104, 'abhi', '2018-05-13', '2018-05-27'),
(102, 'c#', 'sameer', 'Computers', 'kalyani', 102, 'abhay', '2018-01-16', '2018-01-30'),
(103, 'alchemist', 'paulo', 'Novels', 'kalyani', 103, 'suresh', '2018-02-16', '2018-03-02'),
(101, 'c++', 'benjamin', 'Computers', 'cpl', 104, 'abhi', '2018-04-16', '2018-04-30'),
(104, 'snapshot', 'pep', 'Others', 'ncert', 103, 'suresh', '2018-06-14', '2018-06-28');

-- --------------------------------------------------------

--
-- Table structure for table `issue_history`
--

CREATE TABLE `issue_history` (
  `b_id` int(100) NOT NULL,
  `b_name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `publication` varchar(300) NOT NULL,
  `m_id` int(100) NOT NULL,
  `m_name` varchar(100) NOT NULL,
  `issuedate` date NOT NULL,
  `returndate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue_history`
--

INSERT INTO `issue_history` (`b_id`, `b_name`, `author`, `category`, `publication`, `m_id`, `m_name`, `issuedate`, `returndate`) VALUES
(101, 'sameer', 'sameer', 'Computers', 'kalyani', 102, 'abhay', '2018-07-13', '2018-07-27'),
(109, 'arthur', 'arthur', 'Novels', 'redhill', 104, 'abhi', '2018-07-13', '2018-07-27'),
(105, 'hotshot', 'karan', 'Others', 'csb pub', 104, 'abhi', '2018-07-18', '2018-07-27'),
(120, 'pablo escobar ', 'pablo', 'Novels', 'pw pub', 106, 'sushma', '2018-07-19', '2018-07-27'),
(105, 'hotshot', 'karan', 'Others', 'csb pub', 101, 'sam', '2018-07-11', '2018-07-27'),
(108, 'arihant chem', 'abcd', 'Self Help', 'arihant pub', 101, 'sam', '2018-07-10', '2018-07-27'),
(120, 'pablo escobar ', 'pablo', 'Novels', 'pw pub', 101, 'sam', '2018-07-09', '2018-07-27'),
(107, 'story of my life', 'junior', 'Others', 'ncert', 104, 'abhi', '2018-05-13', '2018-07-28'),
(102, 'c#', 'sameer', 'Computers', 'kalyani', 102, 'abhay', '2018-01-16', '2018-07-28'),
(103, 'alchemist', 'paulo', 'Novels', 'kalyani', 103, 'suresh', '2018-02-16', '2018-07-28'),
(101, 'c++', 'benjamin', 'Computers', 'cpl', 104, 'abhi', '2018-04-16', '2018-07-28'),
(117, 'application of derivative', 'mathur', 'Self Help', 'als pub', 107, 'alisha', '2018-06-15', '2018-07-28'),
(104, 'snapshot', 'pep', 'Others', 'ncert', 103, 'suresh', '2018-06-14', '2018-07-28');

-- --------------------------------------------------------

--
-- Table structure for table `memberdb`
--

CREATE TABLE `memberdb` (
  `mem_id` int(100) NOT NULL,
  `mem_name` varchar(200) NOT NULL,
  `f_name` varchar(200) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `memberdb`
--

INSERT INTO `memberdb` (`mem_id`, `mem_name`, `f_name`, `gender`, `dob`, `phone`, `address`) VALUES
(101, 'sam', 'sameer', 'Male', '1980-07-24', '51684165168', 'jal'),
(102, 'abhay', 'surakshit', 'Male', '1992-07-23', '662486362', 'delhi 6'),
(103, 'suresh', 'ramesh', 'Male', '1993-08-07', '656413216', 'ghaziabad'),
(104, 'abhi', 'harish', 'Male', '1995-07-05', '564681325', 'kalinga'),
(105, 'shubham', 'shashank', 'Male', '1980-07-16', '53498130', 'gwalior'),
(106, 'sushma', 'saket', 'Female', '1986-07-28', '89165198666', 'delhi'),
(107, 'alisha', 'suresh', 'Female', '1996-03-27', '7781559744', 'bareily'),
(108, 'simran', 'sushil singh', 'Female', '1998-11-17', '8854752546', 'madras');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `userid` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`userid`, `pass`, `usertype`) VALUES
('admin', '123', 'Admin'),
('emp', '123', 'Employee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookdb`
--
ALTER TABLE `bookdb`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `finetable`
--
ALTER TABLE `finetable`
  ADD KEY `FOREIGN` (`m_id`);

--
-- Indexes for table `issue_history`
--
ALTER TABLE `issue_history`
  ADD KEY `b_id` (`b_id`);

--
-- Indexes for table `memberdb`
--
ALTER TABLE `memberdb`
  ADD PRIMARY KEY (`mem_id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
