/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import static newproject.cred.PASS;
import static newproject.cred.PATH;
import static newproject.cred.PLACE;
import static newproject.cred.USER;

/**
 *
 * @author Tushar Mahajan
 */
public class Newproject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        try
        {
            Connection mycon=DriverManager.getConnection(PATH+PLACE, USER, PASS);
           try
           {
               String qry="select * from usertable";
               PreparedStatement stmnt=mycon.prepareStatement(qry);
               ResultSet rs=stmnt.executeQuery();
               if(rs.next())
               {
                   Login ob=new Login();
                   ob.setVisible(true);
               }
               else
               {
                   JOptionPane.showMessageDialog(null, "Using It For The First Time, So Please Create A Username & Password.");
                   CreateAdmin obj=new CreateAdmin();
                   obj.setVisible(true);
               }
           }
           catch(Exception e)
           {
               JOptionPane.showMessageDialog(null, "Error in Query Due To " +e.getMessage());
           }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error in Connection Due To " +e.getMessage());
        }
    }
    
}
