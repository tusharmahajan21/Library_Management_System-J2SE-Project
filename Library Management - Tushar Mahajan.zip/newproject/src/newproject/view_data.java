/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newproject;
import java.awt.print.PrinterException;
import java.sql.*;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDesktopPane;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Tushar Mahajan
 */
public class view_data extends javax.swing.JInternalFrame implements cred {
int id;
    /**
     * Creates new form addbook
     */
    public view_data() {
        initComponents();
        
        try
        {
            Connection con1=DriverManager.getConnection(PATH+PLACE, USER, PASS);
            try
            {
                String qry1="select * from issuedb";
                PreparedStatement st1=con1.prepareStatement(qry1);
                ResultSet rs1=st1.executeQuery();
                
                if(rs1.next())
                {
                                DefaultTableModel mdl11= (DefaultTableModel) defaultertable.getModel();
                                String b_id,b_name,m_id,m_name,idate,rdate;
                    do
                    {
                        b_id=rs1.getString("b_id");
                        b_name=rs1.getString("b_name");
                        m_id=rs1.getString("m_id");
                        m_name=rs1.getString("m_name");
                        idate=rs1.getString("issuedate");
                        rdate=rs1.getString("returndate");
                      
                        long difference = (new java.util.Date().getTime()-rs1.getDate("issuedate").getTime())/86400000; 
                        long c1 = Math.abs(difference);

                        if(c1>30)
                            {
                                mdl11.addRow(new Object[] {b_id,b_name,m_id,m_name,idate,rdate});   
                            }
                   }
                    while(rs1.next());
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, "Error In Query Due To " +e.getMessage());
            }
            finally
            {
                con1.close();
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error In Connection Due To " +e.getMessage());
        }
        
        
        
        try
        {
            Connection con=DriverManager.getConnection(PATH+PLACE, USER, PASS);
            try
            {
                String qry="select * from bookdb";
                PreparedStatement st=con.prepareStatement(qry);
                ResultSet rs=st.executeQuery();
                if(rs.next())
                {
                    DefaultTableModel mdl= (DefaultTableModel) allbook.getModel();
                    String b_id,b_name,au,cat,pub;
                    do
                    {
                        b_id=rs.getString("book_id");
                        b_name=rs.getString("book_name");
                        au=rs.getString("author");
                        cat=rs.getString("category");
                        pub=rs.getString("publication");
                        mdl.addRow(new Object[] {b_id,b_name,au,cat,pub});
                    }
                    while(rs.next());
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "No Entry");
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, "Error In Query Due To " +e.getMessage());
            }
            finally
            {
                con.close();
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error In Connection Due To " +e.getMessage());
        }
        
        
        
        
       
        
        
        try
        {
            Connection con2=DriverManager.getConnection(PATH+PLACE, USER, PASS);
            try
            {
                String qry2="select * from finetable";
                PreparedStatement st2=con2.prepareStatement(qry2);
                ResultSet rs2=st2.executeQuery();
                if(rs2.next())
                {
                    DefaultTableModel mdl= (DefaultTableModel) finecollected.getModel();
                    String m_id,m_name,fine;
                    do
                    {
                        m_id=rs2.getString("m_id");
                        m_name=rs2.getString("m_name");
                        fine=rs2.getString("fineamt");
                        mdl.addRow(new Object[] {m_id,m_name,fine});
                    }
                    while(rs2.next());
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "No Entry");
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, "Error In Query Due To " +e.getMessage());
            }
            finally
            {
                con2.close();
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error In Connection Due To " +e.getMessage());
        }
        
        totalfine();
        
    }
    void totalfine()
    {
       int f=0;
       for(int x=0;x<finecollected.getRowCount();x++)
       {
           f+=Integer.parseInt(finecollected.getValueAt(x, 2).toString());
       }
       jLabel2.setText(String.valueOf(f));
    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        allbook = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        allmem = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        finecollected = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        defaultertable = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setTitle("View Database");

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("VIEW DATABASE");

        jTabbedPane1.setBackground(new java.awt.Color(0, 153, 153));
        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jTabbedPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusGained(evt);
            }
        });
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));

        allbook.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        allbook.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Book Name", "Author", "Category", "Publication"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(allbook);

        jButton3.setBackground(new java.awt.Color(0, 153, 153));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("PRINT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 717, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(339, 339, 339)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );

        jTabbedPane1.addTab("View Books", jPanel3);

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));

        allmem.setAutoCreateRowSorter(true);
        allmem.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        allmem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Member ID", "Member Name", "Gender", "Date Of Birth", "Phone Number", "Address"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(allmem);

        jButton2.setBackground(new java.awt.Color(0, 153, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("PRINT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(344, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(341, 341, 341))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(18, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 722, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(293, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(51, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("View Members", jPanel4);

        jPanel5.setBackground(new java.awt.Color(0, 153, 153));

        finecollected.setAutoCreateRowSorter(true);
        finecollected.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        finecollected.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Member ID", "Member Name", "Fine Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        finecollected.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                finecollectedMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(finecollected);

        jButton4.setBackground(new java.awt.Color(0, 153, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("PRINT");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("0");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TOTAL FINE COLLECTED");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(92, 92, 92)
                                .addComponent(jLabel2)))
                        .addContainerGap(23, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(85, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(113, 113, 113)
                .addComponent(jButton4)
                .addGap(60, 60, 60))
        );

        jTabbedPane1.addTab("View Collected Fine", jPanel5);

        jPanel6.setBackground(new java.awt.Color(0, 153, 153));

        defaultertable.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        defaultertable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Book Name", "Member ID", "Member Name", "Issue Date", "Return Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        defaultertable.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                defaultertableFocusGained(evt);
            }
        });
        jScrollPane4.setViewportView(defaultertable);

        jButton5.setBackground(new java.awt.Color(0, 153, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setText("PRINT");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("NOTE: Defaulters Are The Ones Who Haven't Returned The Issue Books From More Than 30 Days From the Day Of Issuing.");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 546, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap(163, Short.MAX_VALUE)
                        .addComponent(jButton5)
                        .addGap(114, 114, 114))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jLabel5)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Defaulter List", jPanel6);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(266, 266, 266))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 763, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        MessageFormat mh=new MessageFormat("Members Database");
        MessageFormat mf=new MessageFormat("Page{0}");
        try {
            allmem.print(JTable.PrintMode.FIT_WIDTH, mh, mf);
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this, "Error In Printing Due To " +ex.getMessage());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        MessageFormat mh=new MessageFormat("Books Database");
        MessageFormat mf=new MessageFormat("Page{0}");
        try {
            allbook.print(JTable.PrintMode.FIT_WIDTH, mh, mf);
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this, "Error In Printing Due To " +ex.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         MessageFormat mh=new MessageFormat("Collected Fine Database");
        MessageFormat mf=new MessageFormat("Page{0}");
        try {
            finecollected.print(JTable.PrintMode.FIT_WIDTH, mh, mf);
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this, "Error In Printing Due To " +ex.getMessage());
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
         
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void jTabbedPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusGained
        try
        {
            Connection con1=DriverManager.getConnection(PATH+PLACE, USER, PASS);
            try
            {
                String qry1="select * from memberdb";
                PreparedStatement st1=con1.prepareStatement(qry1);
                ResultSet rs1=st1.executeQuery();
                if(rs1.next())
                {
                    DefaultTableModel mdl= (DefaultTableModel) allmem.getModel();
                    String m_id,m_name,gen,dob,ph,add;
                    do
                    {
                        m_id=rs1.getString("mem_id");
                        m_name=rs1.getString("mem_name");
                       
                        gen=rs1.getString("gender");
                        dob=rs1.getString("dob");
                        ph=rs1.getString("phone");
                        add=rs1.getString("address");
                        mdl.addRow(new Object[] {m_id,m_name,gen,dob,ph,add});
                    }
                    while(rs1.next());
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "No Entry");
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, "Error In Query Due To " +e.getMessage());
            }
            finally
            {
                con1.close();
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error In Connection Due To " +e.getMessage());
        }
    }//GEN-LAST:event_jTabbedPane1FocusGained

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        MessageFormat mh=new MessageFormat("Collected Fine Database");
        MessageFormat mf=new MessageFormat("Page{0}");
        try {
            defaultertable.print(JTable.PrintMode.FIT_WIDTH, mh, mf);
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this, "Error In Printing Due To " +ex.getMessage());
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void finecollectedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_finecollectedMouseClicked
        int c=Integer.parseInt((String) finecollected.getValueAt(finecollected.getSelectedRow(), 0));
        memdetail.ID=c;
        memdetail obj=new memdetail();
        parentclass.jDesktopPane1.add(obj);
        obj.setVisible(true);
        
        
        
    }//GEN-LAST:event_finecollectedMouseClicked

    private void defaultertableFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_defaultertableFocusGained
        
    }//GEN-LAST:event_defaultertableFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable allbook;
    private javax.swing.JTable allmem;
    private javax.swing.JTable defaultertable;
    private javax.swing.JTable finecollected;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
